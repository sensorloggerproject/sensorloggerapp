import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sensordatagetter/util/services/time_accuracy.dart';
import 'package:sensordatagetter/view/bottom_nav_bar/bottom_navigation_bar.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Permission.locationAlways.request();
  await Permission.locationWhenInUse.request();
  TimeAccuracy.milleseconds = await TimeAccuracy.getTimeDifference();
  TimeAccuracy.time = TimeAccuracy.convertTime(TimeAccuracy.milleseconds!);
  runApp(ScreenUtilInit(
    designSize: Size(MediaQueryData.fromWindow(WidgetsBinding.instance!.window).size.width,
        MediaQueryData.fromWindow(WidgetsBinding.instance!.window).size.height),
    minTextAdapt: true,
    splitScreenMode: true,
    builder: (_, Widget) => MaterialApp(
      debugShowCheckedModeBanner: false,
      home: BottomNavigationScreen(),
    ),
  ));
}
