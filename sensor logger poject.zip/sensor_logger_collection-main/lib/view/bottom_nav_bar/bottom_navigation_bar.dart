import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:salomon_bottom_bar/salomon_bottom_bar.dart';
import 'package:stats/stats.dart';

import '../../util/app_color.dart';
import 'home_screen.dart';
import 'list_screen.dart';

class BottomNavigationScreen extends StatefulWidget {
  const BottomNavigationScreen({Key? key}) : super(key: key);

  @override
  _BottomNavigationScreenState createState() => _BottomNavigationScreenState();
}

class _BottomNavigationScreenState extends State<BottomNavigationScreen> with SingleTickerProviderStateMixin {
  var pages = [HomeScreen(), ListScreen()];

  int currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () async {
          SystemNavigator.pop();
          return true;
        },
        child: SafeArea(
          child: Scaffold(
            backgroundColor: AppColors.bgColor,
            body: Center(
              child: pages[currentIndex],
            ),
            bottomNavigationBar: Stack(
              children: [
                SalomonBottomBar(
                  duration: Duration(seconds: 1),
                  currentIndex: currentIndex,
                  onTap: (i) {
                    setState(() {
                      currentIndex = i;
                    });
                  },
                  items: [
                    /// Home
                    customBottomNavigationItem("Home", Icon(Icons.home)),

                    /// list of recorded data
                    customBottomNavigationItem("List", Icon(Icons.list_alt)),
                  ],
                ),
              ],
            ),
          ),
        ));
  }

  customBottomNavigationItem(String label, Widget icon) {
    return SalomonBottomBarItem(icon: icon, title: Text(label), selectedColor: AppColors.btnColor);
  }
}
