import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:sensordatagetter/util/app_color.dart';
import 'package:sensordatagetter/util/app_navigator.dart';
import 'package:sensordatagetter/view/files_screen.dart';

import '../../util/asset_path.dart';
import '../../util/style.dart';

class ListScreen extends StatefulWidget {
  const ListScreen({Key? key}) : super(key: key);

  @override
  _ListScreenState createState() => _ListScreenState();
}

class _ListScreenState extends State<ListScreen> {
  List<String> allSensors = [
    'Accelerometer',
    'Gyroscope',
    'Magnetometer',
    'Gravity',
    'Microphone noise level',
    'Microphone audio',
    'Light',
    'Barometer',
    'Location',
    'Bluetooth'
  ];
  List<String> iconsList = [
    AssetsPath.accelerometer,
    AssetsPath.gyroscope,
    AssetsPath.magnetometer,
    AssetsPath.gravity,
    AssetsPath.noise,
    AssetsPath.audio,
    AssetsPath.light,
    AssetsPath.barometer,
    AssetsPath.location,
    AssetsPath.bluetooth
  ];
  @override
  Widget build(BuildContext context) {
    return SafeArea(child: Scaffold(
      backgroundColor: AppColors.bgColor,
      appBar: AppBar(
        backgroundColor: AppColors.bgColor,
        elevation: 1,
        title: Text(
          "Recording's List",
          style: TextStyle(color: AppColors.appBarTextColor,fontSize: 16.sp,fontWeight: FontWeight.w600),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(18.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            Text(
              "Saved Recordings",
              style: headingStyle(),
            ),

            // list of all sensors list tile
            Expanded(
              child: ListView.builder(
                itemCount: allSensors.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    onTap: (){
                      AppNavigator.push(context, FilesScreen(folderName: allSensors[index],));
                    },
                      leading: Image.asset(
                        iconsList[index],
                        height: 25.h,
                      ),
                      title: Text(
                        allSensors[index],
                        style: sensorTitle(),
                      ),
                      subtitle: Text('device sensors data'),
                      contentPadding: EdgeInsets.all(10),
                  );
                }
            ),
            ),
          ],
        ),
      ),
    ));
  }
}
