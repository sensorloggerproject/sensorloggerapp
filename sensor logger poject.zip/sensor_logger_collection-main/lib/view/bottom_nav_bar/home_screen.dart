import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:location/location.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sensordatagetter/util/alert.dart';
import 'package:sensordatagetter/util/app_color.dart';
import 'package:sensordatagetter/util/asset_path.dart';
import 'package:sensordatagetter/util/services/sensors_controller.dart';
import 'package:wakelock/wakelock.dart';

import '../../util/services/time_accuracy.dart';
import '../../util/style.dart';
import '../../widget/custom_widgets.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<String> allSensors = [
    'Accelerometer',
    'Gyroscope',
    'Magnetometer',
    'Gravity',
    'Microphone noise level',
    'Microphone audio',
    'Light',
    'Barometer',
    'Location',
    'Bluetooth'
  ];
  List<bool> selectedSensors = [
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    true
  ];
  List<String> iconsList = [
    AssetsPath.accelerometer,
    AssetsPath.gyroscope,
    AssetsPath.magnetometer,
    AssetsPath.gravity,
    AssetsPath.noise,
    AssetsPath.audio,
    AssetsPath.light,
    AssetsPath.barometer,
    AssetsPath.location,
    AssetsPath.bluetooth
  ];
  List<String> suffixes = [
    "ms",
    "ms",
    "ms",
    "ms",
    "ms",
    "kHz",
    "ms",
    "ms",
    "sec",
    "sec",
  ];
  List<int> defaultSuffixValues = [5, 5, 5, 5, 10, 44, 10, 100, 10, 60];
  List<TextEditingController> controllers = [
    TextEditingController(),
    TextEditingController(),
    TextEditingController(),
    TextEditingController(),
    TextEditingController(),
    TextEditingController(),
    TextEditingController(),
    TextEditingController(),
    TextEditingController(),
    TextEditingController(),
  ];

  void setDefaultValues() {
    for (int index = 0; index < defaultSuffixValues.length; index++) {
      controllers[index].text = defaultSuffixValues[index].toString();
    }
    setState(() {});
  }

  bool isStart = false;

  FlutterBluetoothSerial bluetooth = FlutterBluetoothSerial.instance;

  Location location = new Location();
  bool? _serviceEnabled;
  LocationData? _locationData;

  @override
  void initState() {
    turnONBluetooth();
    requestPermissions();
    enableLocation();
    setDefaultValues();
    TimeAccuracy.getTimeDifference();
  }

  requestPermissions() async {
    await Permission.storage.request();
    await Permission.manageExternalStorage.request();
  }

  turnONBluetooth() async {
    bool? result = await bluetooth.isEnabled;

    if (result == false) {
      bluetooth.requestEnable();
      if (FlutterBluePlus.instance.isScanning == false) {
        FlutterBluePlus.instance.startScan(timeout: Duration(seconds: 2));
      }
    } else {
      print("bluetooth enabled already");
    }
    if (FlutterBluePlus.instance.isScanning == false) {
      FlutterBluePlus.instance.startScan(timeout: Duration(seconds: 2));
    }
  }

  enableLocation() async {
    _serviceEnabled = await location.serviceEnabled();
    if (!_serviceEnabled!) {
      _serviceEnabled = await location.requestService();
      if (!_serviceEnabled!) {
        return;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      backgroundColor: AppColors.bgColor,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(80.h),
        child: AppBar(
          backgroundColor: AppColors.bgColor,
          elevation: 1,
          title: Text(
            "Sensor Logger-Data Collection",
            style: TextStyle(
                color: AppColors.appBarTextColor,
                fontSize: 18.sp,
                fontWeight: FontWeight.bold,
                fontStyle: FontStyle.italic),
          ),
          flexibleSpace: Align(
            alignment: Alignment.topRight,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: SizedBox(
                child: Column(
                  children: [
                    IconButton(
                        onPressed: () async {
                          TimeAccuracy.milleseconds =
                              await TimeAccuracy.findDifference();
                          TimeAccuracy.time = TimeAccuracy.convertTime(
                              TimeAccuracy.milleseconds!);
                          MyAlert.showToast("Time updated");
                          setState(() {});
                        },
                        icon: Icon(
                          Icons.sync,
                          color: Colors.green,
                        )),
                    Expanded(
                        child: Text(
                      '${TimeAccuracy.time} from actual time',
                      style: TextStyle(color: Colors.black),
                    )),
                  ],
                ),
              ),
            ),
          ),
          centerTitle: false,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(18.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Sensors",
              style: headingStyle(),
            ),

            // list of all sensors list tile
            Expanded(
              child: ListView.builder(
                itemCount: allSensors.length,
                itemBuilder: (context, index) {
                  return SwitchListTile(
                      value: selectedSensors[index],
                      secondary: Image.asset(
                        iconsList[index],
                        height: 25.h,
                      ),
                      title: Text(
                        allSensors[index],
                        style: sensorTitle(),
                      ),
                      subtitle: customTextField(
                          label: "Interval",
                          suffix: suffixes[index],
                          controller: controllers[index]),
                      contentPadding: EdgeInsets.all(10),
                      onChanged: (val) async {
                        if (index == 8) {
                          await Permission.location.request();
                        }
                        if (isStart) {
                          MyAlert.showToast(
                              "Currently sensors are running, stop recording first");
                        } else {
                          if (index == 8) {
                            // if(Permission.location.isGranted==true){
                            setState(() {
                              selectedSensors[index] = val;
                            });
                            // }else{
                            //   print("Permanent denied? ${Permission.location.isGranted==true}");
                            // }

                          } else {
                            setState(() {
                              selectedSensors[index] = val;
                            });
                          }
                        }
                      });
                },
              ),
            ),

            Center(
              child: Container(
                width: ScreenUtil().screenWidth,
                height: 55.h,
                child: ElevatedButton(
                  onPressed: () {
                    if (allOff()) {
                      MyAlert.showToast("All sensors are off");
                    } else {
                      if (isStart) {
                        isStart = false;
                        stopGetting();
                      } else {
                        getControllerValues();
                        if (selectedSensors[4] && selectedSensors[5]) {
                          MyAlert.showToast(
                              "Noise and sound recoder can't be used at same time because both uses common mic");
                        } else {
                          isStart = true;
                          startGetting();
                        }
                      }
                      setState(() {});
                    }
                  },
                  child: isStart
                      ? Text(
                          'Stop Recording',
                          style: btnTextStyle(),
                        )
                      : Text(
                          'Start Recording',
                          style: btnTextStyle(),
                        ),
                  style: ElevatedButton.styleFrom(
                      primary: isStart ? Colors.red : AppColors.btnColor,
                      shape: StadiumBorder(),
                      padding:
                          EdgeInsets.symmetric(horizontal: 50, vertical: 20),
                      textStyle:
                          TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
                ),
              ),
            ),
          ],
        ),
      ),
    ));
  }

  List<int> controllerValues = [];
  // get textfieldValues
  getControllerValues() {
    controllerValues.clear();
    for (int index = 0; index < controllers.length; index++) {
      controllerValues.add(int.parse(controllers[index].text));
    }
  }

  SensorsController sensorsController = SensorsController();

  Future<void> startGetting() async {
    Wakelock.enable();
    sensorsController.startTimer();
    // accelero
    if (selectedSensors[0]) {
      sensorsController.getAccelerometerStream(controllerValues[0]);
    }
    // gyero
    if (selectedSensors[1]) {
      sensorsController.getGyroscopeStream(controllerValues[1]);
    }
    //magneto
    if (selectedSensors[2]) {
      sensorsController.getMagnetometerStream(controllerValues[2]);
    }
    //gravity
    if (selectedSensors[3]) {
      sensorsController.getGravityStream(controllerValues[3]);
    }
    //noise
    if (selectedSensors[4]) {
      sensorsController.getNoiseStream(controllerValues[4]);
    }
    //microphone audio
    if (selectedSensors[5]) {
      sensorsController
          .getAndSaveMicroPhoneRecording(controllerValues[5] * 1000);
    }
    //light
    if (selectedSensors[6]) {
      sensorsController.getLightStream(controllerValues[6]);
    }
    //barometer
    if (selectedSensors[7]) {
      sensorsController.getBarometerStream(controllerValues[7]);
    }
    //location
    if (selectedSensors[8]) {
      sensorsController.getLocationStream(controllerValues[8]);
    }
    //bluetooth
    if (selectedSensors[9]) {
      sensorsController.getBluetoothStream(controllerValues[9]);
    }
  }

  void stopGetting() {
    sensorsController.destroyAudio();
    Wakelock.disable();
    sensorsController.cancel(selectedSensors);
  }

  allOff() {
    for (var sensor in selectedSensors) {
      if (sensor) {
        return false;
      }
    }
    return true;
  }
}
