import 'dart:developer';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sensordatagetter/models/noiseModel.dart';
import 'package:sensordatagetter/util/app_color.dart';

import 'dart:io' as io;
import 'package:path/path.dart';
import 'package:share_plus/share_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:stats/stats.dart';

import '../util/alert.dart';
import '../util/asset_path.dart';
import '../util/services/file_manager.dart';
import 'package:csv/csv.dart';
import 'dart:convert' show utf8;

import '../util/sound_function.dart';
import '../util/style.dart';
import '../widget/button_widget.dart';

class FilesScreen extends StatefulWidget {
  String? folderName;

  FilesScreen({Key? key, this.folderName}) : super(key: key);

  @override
  _FilesScreenState createState() => _FilesScreenState();
}

class _FilesScreenState extends State<FilesScreen> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      backgroundColor: AppColors.bgColor,
      appBar: AppBar(
        backgroundColor: AppColors.bgColor,
        elevation: 1,
        iconTheme: IconThemeData(color: Colors.black),
        title: Text(
          "${widget.folderName}",
          style: TextStyle(color: AppColors.appBarTextColor),
        ),
        centerTitle: true,
      ),
      body: Padding(
          padding: const EdgeInsets.all(18.0),
          child: isLoading
              ? Center(child: CircularProgressIndicator())
              : file!.length == 0
                  ? Center(child: Text('No file yet'))
                  : ListView.builder(
                      itemCount: file!.length,
                      itemBuilder: (BuildContext context, int index) {
                        if (widget.folderName == "Microphone noise level" ||
                            widget.folderName == "Microphone audio") {
                          return Padding(
                            padding: const EdgeInsets.all(6.0),
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                border: Border.all(color: AppColors.btnColor),
                              ),
                              padding: EdgeInsets.all(5),
                              child: ListTile(
                                leading: Icon(
                                  Icons.file_copy_rounded,
                                  color: AppColors.btnColor,
                                ),
                                title: Text(basename(file![index].toString())),
                                trailing: SizedBox(
                                  width: 110.w,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      Visibility(
                                        visible: !basename(file![index].toString()).contains("Processed"),
                                        child: InkWell(
                                          borderRadius: BorderRadius.circular(30),
                                          child: Padding(
                                              padding: const EdgeInsets.all(5.0),
                                              child: Image.asset(
                                                AssetsPath.process,
                                                height: 30,
                                                width: 30,
                                              )),
                                          onTap: () async {
                                            // if (widget.folderName ==
                                            //     "Microphone audio") {
                                            //   processFile(
                                            //       context,
                                            //       basename(
                                            //           file![index].toString()));
                                            //   return;
                                            // }

                                            processFile(context, basename(file![index].toString()));
                                          },
                                        ),
                                      ),
                                      InkWell(
                                        borderRadius: BorderRadius.circular(30),
                                        child: Padding(
                                          padding: const EdgeInsets.all(5.0),
                                          child: Icon(
                                            Icons.delete,
                                            color: Colors.red,
                                          ),
                                        ),
                                        onTap: () async {
                                          String path = await getFilePath(basename(file![index].toString()));
                                          showDeleteAlert(context, path);
                                        },
                                      ),
                                      InkWell(
                                        borderRadius: BorderRadius.circular(30),
                                        child: Padding(
                                          padding: const EdgeInsets.all(5.0),
                                          child: Icon(
                                            Icons.share,
                                            color: AppColors.btnColor,
                                          ),
                                        ),
                                        onTap: () async {
                                          shareFile(basename(file![index].toString()));
                                        },
                                      ),
                                    ],
                                  ),
                                ),
                                contentPadding: EdgeInsets.symmetric(horizontal: 8.0),
                              ),
                            ),
                          );
                        }
                        return Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15),
                              border: Border.all(color: AppColors.btnColor),
                            ),
                            padding: EdgeInsets.all(5),
                            child: ListTile(
                              leading: Icon(
                                Icons.file_copy_rounded,
                                color: AppColors.btnColor,
                              ),
                              title: Text(basename(file![index].toString())),
                              trailing: SizedBox(
                                width: 100.w,
                                child: Row(
                                  children: [
                                    IconButton(
                                      icon: Icon(
                                        Icons.delete,
                                        color: Colors.red,
                                      ),
                                      onPressed: () async {
                                        String path = await getFilePath(basename(file![index].toString()));
                                        showDeleteAlert(context, path);
                                      },
                                    ),
                                    IconButton(
                                      icon: Icon(
                                        Icons.share,
                                        color: AppColors.btnColor,
                                      ),
                                      onPressed: () {
                                        shareFile(basename(file![index].toString()));
                                      },
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        );
                      })),
    ));
  }

  //Declare Globaly
  String? directory;
  List? file;
  bool isLoading = true;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _listofFiles();
  }

  // Make New Function
  void _listofFiles() async {
    await FileManager.createFolderInAppDocDir(widget.folderName!);
    directory = (await getApplicationDocumentsDirectory()).path;
    setState(() {
      file = io.Directory("$directory/${widget.folderName}/")
          .listSync(); //use your folder name insted of resume.
      isLoading = false;
    });
  }

  Future<void> shareFile(String fileName) async {
    await Permission.storage.request();
    directory = (await getApplicationDocumentsDirectory()).path;
    fileName = fileName.replaceAll('\'', '');
    String filePath = "$directory/${widget.folderName}/${fileName}";
    print("file path $filePath");
    Share.shareFiles(["$filePath"], text: 'Great picture');
  }

  Future<String> getFilePath(String fileName) async {
    await Permission.storage.request();
    directory = (await getApplicationDocumentsDirectory()).path;
    fileName = fileName.replaceAll('\'', '');
    String filePath = "$directory/${widget.folderName}/${fileName}";
    return filePath;
  }

  void processFile(BuildContext context, String fileName) async {
    String filePath = await getFilePath(fileName);
    if (widget.folderName == "Microphone audio") {
      setState(() {
        isLoading = true;
      });
      await waveAudio(filePath);
      setState(() {
        _listofFiles();
      });
      return;
    }

    File file = File(filePath);
    Stream input = new File(file.path).openRead();
    List<double> noiseLevel = [];
    List<int> timeStamps = [];

    final fields = await input.transform(utf8.decoder).transform(new CsvToListConverter()).toList();

    for (var value in fields) {
      if (value[0] == "time") {
        continue;
      }

      if (!value[1].toString().contains("Infinity")) {
        timeStamps.add(value[0]);
        noiseLevel.add(value[1]);
      }
    }

    showMeanDeviation(context, noiseLevel, timeStamps, fileName);
  }

  showDeleteAlert(BuildContext context, String filePath) {
    print("File to delete path is $filePath");

    // set up the buttons
    Widget cancelButton = TextButton(
      child: Text("Cancel"),
      onPressed: () {
        Navigator.pop(context);
      },
    );
    Widget continueButton = TextButton(
      child: Text("Delete"),
      onPressed: () async {
        await File('$filePath').delete();
        Navigator.pop(context);
        setState(() {
          isLoading = true;
          _listofFiles();
        });
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("Delete"),
      content: Text("Do you really want to delete this file?"),
      actions: [
        cancelButton,
        continueButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  Future<dynamic> showMeanDeviation(
      BuildContext context, List<double> noiseLevel, List<int> timeStamps, String oldName) {
    TextEditingController standardDeviationTextEditor = TextEditingController(text: "1");
    TextEditingController meanTextEditor = TextEditingController(text: "2");
    TextEditingController timeWindowTextEditor = TextEditingController(text: "1");

    return showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(builder: (context, setState) {
          return AlertDialog(
            insetPadding: const EdgeInsets.all(12),
            // shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(15.0))),
            // backgroundColor: Colors.white,
            content: SizedBox(
              width: double.infinity,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Flexible(
                          child: Text(
                            "Input standard deviation and mean",
                            style: TextStyle(color: AppColors.deviationDialogColor, fontSize: 22),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 11),
                    Text(
                      "Standard Deviation",
                      textAlign: TextAlign.center,
                      style: TextStyle(color: AppColors.deviationDialogColor),
                    ),
                    const SizedBox(height: 11),
                    TextFormField(
                        controller: standardDeviationTextEditor,
                        keyboardType: TextInputType.number,
                        decoration: kInputFieldDecoration),
                    const SizedBox(height: 29),
                    Text(
                      "Mean",
                      textAlign: TextAlign.center,
                      style: TextStyle(color: AppColors.deviationDialogColor),
                    ),
                    const SizedBox(height: 11),
                    TextFormField(
                        controller: meanTextEditor,
                        keyboardType: TextInputType.number,
                        decoration: kInputFieldDecoration),
                    Text(
                      "Time Window (mins)",
                      textAlign: TextAlign.center,
                      style: TextStyle(color: AppColors.deviationDialogColor),
                    ),
                    const SizedBox(height: 11),
                    TextFormField(
                        controller: timeWindowTextEditor,
                        keyboardType: TextInputType.number,
                        decoration: kInputFieldDecoration),
                    const SizedBox(height: 26),
                    AppButton(
                      color: AppColors.deviationDialogColor,
                      text: "Export",
                      height: 55,
                      width: double.infinity,
                      onPressed: () async {
                        List<ProcessedNoiseModel> processNoise = [];
                        Stats stats = Stats.fromData(noiseLevel);
                        int timeWindow = int.parse(
                            (timeWindowTextEditor.text.isEmpty || timeWindowTextEditor.text == "0")
                                ? "1"
                                : timeWindowTextEditor.text);

                        if ((timeStamps).isEmpty) {
                          return;
                        }
                        DateTime startTime = DateTime.fromMillisecondsSinceEpoch(timeStamps.first);
                        DateTime endTime = DateTime.fromMillisecondsSinceEpoch(timeStamps.last);
                        int timeDifference = endTime.difference(startTime).inMinutes;

                        if (timeDifference <= timeWindow || timeWindow == 1) {
                          print("thwe");
                          stats = Stats.fromData(noiseLevel);
                          var comparingValue = (int.parse(standardDeviationTextEditor.text.isEmpty
                                      ? "2"
                                      : standardDeviationTextEditor.text) *
                                  stats.standardDeviation) +
                              (int.parse(meanTextEditor.text.isEmpty ? "1" : meanTextEditor.text) *
                                  stats.average);

                          for (int i = 0; i <= noiseLevel.length - 1; i++) {
                            if (noiseLevel[i] >= comparingValue) {
                              processNoise.add(ProcessedNoiseModel(
                                time: timeStamps[i].toString(),
                              ));

                              continue;
                            }
                          }

                          await ProcessedNoiseModel().saveProcessNoiseValues(
                              processNoise,
                              stats.standardDeviation.toStringAsFixed(3),
                              stats.average.toStringAsFixed(3),
                              "1",
                              oldName.split(".").first);
                          Navigator.pop(context);
                          setState(() {
                            isLoading = true;
                            _listofFiles();
                          });
                          return;
                        }

                        DateTime loopEndTime = startTime;
                        int startIndex = 0;
                        int lastIndex = timeStamps.length;

                        while (endTime.difference(loopEndTime).inMilliseconds >= 0) {
                          loopEndTime = loopEndTime.add(Duration(minutes: timeWindow));
                          List<double> noise = [];
                          List<int> times = [];
                          for (int i = startIndex; i <= lastIndex - 1; i++) {
                            if (loopEndTime
                                    .difference(DateTime.fromMillisecondsSinceEpoch(timeStamps[i]))
                                    .inMilliseconds <=
                                0) {
                              startIndex = i;
                              break;
                            }
                            noise.add(noiseLevel[i]);
                            times.add(timeStamps[i]);
                          }

                          Stats stats = Stats.fromData(noise);
                          print(stats.standardDeviation);
                          print(stats.average);

                          var comparingValue = (int.parse(standardDeviationTextEditor.text.isEmpty
                                      ? "2"
                                      : standardDeviationTextEditor.text) *
                                  stats.standardDeviation) +
                              (int.parse(meanTextEditor.text.isEmpty ? "1" : meanTextEditor.text) *
                                  stats.average);

                          for (int i = 0; i <= noise.length - 1; i++) {
                            if (noise[i] >= comparingValue) {
                              processNoise.add(ProcessedNoiseModel(
                                time: times[i].toString(),
                              ));

                              continue;
                            }
                          }
                        }
                        await ProcessedNoiseModel().saveProcessNoiseValues(
                            processNoise,
                            stats.standardDeviation.toStringAsFixed(3),
                            stats.average.toStringAsFixed(3),
                            timeWindow.toString(),
                            oldName.split(".").first);
                        Navigator.pop(context);
                        setState(() {
                          isLoading = true;
                          _listofFiles();
                        });
                      },
                    ),
                  ],
                ),
              ),
            ),
          );
        });
      },
    );
  }
}
