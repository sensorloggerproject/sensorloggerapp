import 'package:csv/csv.dart';

import '../util/services/file_manager.dart';

class MagnetoModel{
  String? time;
  double? zAxis,yAxis,xAxis;

  MagnetoModel({this.time, this.zAxis, this.yAxis, this.xAxis});


  // save Accelero values into csv

  Future<void> saveMagnetoValues(List<MagnetoModel> magnetoList,String startTime,String endTime) async {

    List<List<dynamic>> rows = [];

    List<dynamic> row = [];
    row.add("time");
    row.add("z");
    row.add("y");
    row.add("x");
    rows.add(row);
    for (int i = 0; i < magnetoList.length; i++) {
      List<dynamic> row = [];
      row.add(magnetoList[i].time);
      row.add(magnetoList[i].zAxis);
      row.add(magnetoList[i].yAxis);
      row.add(magnetoList[i].xAxis);
      rows.add(row);
    }

    String csv = const ListToCsvConverter().convert(rows);
    await FileManager.writeIntoFolder("Magnetometer", csv,startTime,endTime);
  }
}