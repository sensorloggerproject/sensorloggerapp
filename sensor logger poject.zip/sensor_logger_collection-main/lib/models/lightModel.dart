import 'package:csv/csv.dart';

import '../util/services/file_manager.dart';

class LightModel{
  String? time;
  int? lux;

  LightModel({this.time,this.lux});



  Future<void> saveLightValues(List<LightModel> lightList,String startTime,String endTime) async {

    List<List<dynamic>> rows = [];

    List<dynamic> row = [];
    row.add("time");
    row.add("lux");
    rows.add(row);
    for (int i = 0; i < lightList.length; i++) {
      List<dynamic> row = [];
      row.add(lightList[i].time);
      row.add(lightList[i].lux);
      rows.add(row);
    }

    String csv = const ListToCsvConverter().convert(rows);
    await FileManager.writeIntoFolder("Light", csv,startTime,endTime);
  }
}