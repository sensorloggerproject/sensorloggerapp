import 'package:csv/csv.dart';

import '../util/services/file_manager.dart';

class GyeroModel{
  String? time;
  double? zAxis,yAxis,xAxis;

  GyeroModel({this.time, this.zAxis, this.yAxis, this.xAxis});

  Future<void> saveGyeroValues(List<GyeroModel> gyeroList,String startTime,String endTime) async {

    List<List<dynamic>> rows = [];

    List<dynamic> row = [];
    row.add("time");
    row.add("z");
    row.add("y");
    row.add("x");
    rows.add(row);
    for (int i = 0; i < gyeroList.length; i++) {
      List<dynamic> row = [];
      row.add(gyeroList[i].time);
      row.add(gyeroList[i].zAxis);
      row.add(gyeroList[i].yAxis);
      row.add(gyeroList[i].xAxis);
      rows.add(row);
    }

    String csv = const ListToCsvConverter().convert(rows);
    await FileManager.writeIntoFolder("Gyroscope", csv,startTime,endTime);
  }
}