import 'package:csv/csv.dart';

import '../util/services/file_manager.dart';

// print("Noise reading is : $noiseReading");
// int updatedTime = DateTime
//     .now()
//     .millisecondsSinceEpoch + TimeAccuracy.milleseconds!;
// noiseModelList.add(NoiseModel(
// time: updatedTime.toString(), dBFS: noiseReading.maxDecibel));

class ProcessedAudioModel {
  String? time;
  String? amplitude;
  String? frequency;

  ProcessedAudioModel({this.time, this.frequency, this.amplitude});

  Future<void> saveProcessAudioValues(List<ProcessedAudioModel> processAudioList, String? oldName) async {
    print('//////// saving audio readings');
    List<List<dynamic>> rows = [];

    List<dynamic> row = [];
    row.add("time");
    row.add("array of peak values of frequency");
    row.add("array of amplitude (main peek detection)");
    rows.add(row);

    for (int i = 0; i < processAudioList.length; i++) {
      List<dynamic> row = [];
      row.add(processAudioList[i].time);
      row.add(processAudioList[i].frequency);
      row.add(processAudioList[i].amplitude);
      rows.add(row);
    }

    String csv = const ListToCsvConverter().convert(rows);
    await FileManager.writeIntoFolder("Microphone audio", csv, "", "",
        oldName: oldName, audioIsProcessed: true);
  }
}
