import 'package:csv/csv.dart';

import '../util/services/file_manager.dart';

class AcceleroModel{
  String? time;
  double? zAxis,yAxis,xAxis;

  AcceleroModel({this.time, this.zAxis, this.yAxis, this.xAxis});


  // save Accelero values into csv

      Future<void> saveAcceleroValues(List<AcceleroModel> acceleroList,String startTime,String endTime) async {

        List<List<dynamic>> rows = [];

        List<dynamic> row = [];
        row.add("time");
        row.add("z");
        row.add("y");
        row.add("x");
        rows.add(row);
        for (int i = 0; i < acceleroList.length; i++) {
          List<dynamic> row = [];
          row.add(acceleroList[i].time);
          row.add(acceleroList[i].zAxis);
          row.add(acceleroList[i].yAxis);
          row.add(acceleroList[i].xAxis);
          rows.add(row);
        }

        String csv = const ListToCsvConverter().convert(rows);
        await FileManager.writeIntoFolder("Accelerometer", csv,startTime,endTime);
      }
}