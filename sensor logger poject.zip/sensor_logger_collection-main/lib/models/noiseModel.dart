import 'package:csv/csv.dart';

import '../util/services/file_manager.dart';

class NoiseModel {
  String? time;
  double? dBFS;

  NoiseModel({this.time, this.dBFS});

  Future<void> saveNoiseValues(List<NoiseModel> noiseList, String startTime, String endTime) async {
    print('//////// saving noice readings');
    List<List<dynamic>> rows = [];

    List<dynamic> row = [];
    row.add("time");
    row.add("dBFS");
    rows.add(row);
    for (int i = 0; i < noiseList.length; i++) {
      List<dynamic> row = [];
      row.add(noiseList[i].time);
      row.add(noiseList[i].dBFS);
      rows.add(row);
    }

    String csv = const ListToCsvConverter().convert(rows);
    await FileManager.writeIntoFolder("Microphone noise level", csv, startTime, endTime);
  }
}

class ProcessedNoiseModel {
  String? time;

  ProcessedNoiseModel({this.time});

  Future<void> saveProcessNoiseValues(List<ProcessedNoiseModel> processNoiseList, String deviationValue,
      String meanValue, String timeWindowValue, String? oldName) async {
    print('//////// saving noice readings');
    List<List<dynamic>> rows = [];

    List<dynamic> row = [];
    row.add("time");
    rows.add(row);
    for (int i = 0; i < processNoiseList.length; i++) {
      List<dynamic> row = [];
      row.add(processNoiseList[i].time);

      rows.add(row);
    }

    String csv = const ListToCsvConverter().convert(rows);
    await FileManager.writeIntoFolder("Microphone noise level", csv, meanValue, deviationValue,
        timeWindowValue: timeWindowValue, oldName: oldName);
  }
}
