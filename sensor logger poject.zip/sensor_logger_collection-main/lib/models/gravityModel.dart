import 'package:csv/csv.dart';

import '../util/services/file_manager.dart';

class GravityModel{
  String? time;
  double? zAxis,yAxis,xAxis;

  GravityModel({this.time, this.zAxis, this.yAxis, this.xAxis});


  // save Accelero values into csv

  Future<void> saveGravityValues(List<GravityModel> gravityList,String startTime,String endTime) async {

    List<List<dynamic>> rows = [];

    List<dynamic> row = [];
    row.add("time");
    row.add("z");
    row.add("y");
    row.add("x");
    rows.add(row);
    for (int i = 0; i < gravityList.length; i++) {
      List<dynamic> row = [];
      row.add(gravityList[i].time);
      row.add(gravityList[i].zAxis);
      row.add(gravityList[i].yAxis);
      row.add(gravityList[i].xAxis);
      rows.add(row);
    }

    String csv = const ListToCsvConverter().convert(rows);
    await FileManager.writeIntoFolder("Gravity", csv,startTime,endTime);
  }
}