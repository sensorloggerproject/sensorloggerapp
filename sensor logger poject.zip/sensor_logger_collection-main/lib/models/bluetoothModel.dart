import 'package:csv/csv.dart';

import '../util/services/file_manager.dart';

class BluetoothModel {
  String? time;
  int? rssi;
  String? bleMacAddress;
  String? chirp;
  BluetoothModel({this.time, this.rssi, this.bleMacAddress, this.chirp});

  Future<void> saveBluetoothValues(
      List<BluetoothModel> bluetoothList, String startTime, String endTime) async {
    List<List<dynamic>> rows = [];

    List<dynamic> row = [];
    row.add("time");
    row.add("RSSI");
    row.add("BLE MAC");
    row.add("Chirp");

    rows.add(row);
    for (int i = 0; i < bluetoothList.length; i++) {
      List<dynamic> row = [];
      row.add(bluetoothList[i].time);
      row.add(bluetoothList[i].rssi);
      row.add(bluetoothList[i].bleMacAddress);
      row.add(bluetoothList[i].chirp);

      rows.add(row);
    }

    String csv = const ListToCsvConverter().convert(rows);
    await FileManager.writeIntoFolder("Bluetooth", csv, startTime, endTime);
  }
}
