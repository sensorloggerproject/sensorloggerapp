import 'package:csv/csv.dart';

import '../util/services/file_manager.dart';

class BaroModel{
  String? time;
  double? pressure;
  BaroModel({this.time,this.pressure});



  Future<void> saveBaroValues(List<BaroModel> baroListList,String startTime,String endTime) async {

    List<List<dynamic>> rows = [];

    List<dynamic> row = [];
    row.add("time");
    row.add("hpA");

    rows.add(row);
    for (int i = 0; i < baroListList.length; i++) {
      List<dynamic> row = [];
      row.add(baroListList[i].time);
      row.add(baroListList[i].pressure);

      rows.add(row);
    }

    String csv = const ListToCsvConverter().convert(rows);
    await FileManager.writeIntoFolder("Barometer", csv,startTime,endTime);
  }
}