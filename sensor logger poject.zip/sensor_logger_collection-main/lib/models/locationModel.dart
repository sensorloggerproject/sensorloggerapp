import 'package:csv/csv.dart';

import '../util/services/file_manager.dart';

class LocationModel{
  String? time;
  double? bearingAccuracy;
  double? speedAccuracy;
  double? verticalAccuracy;
  double? horizontalAccuracy;
  double? speed;
  double? bearing;
 double? altitude;
  double? longitude;
 double? latitude;


  LocationModel({this.time,this.bearingAccuracy,this.speedAccuracy,this.verticalAccuracy,this.horizontalAccuracy,this.speed,this.bearing,this.altitude,this.longitude,this.latitude});



  Future<void> saveLocationValues(List<LocationModel> locationModelList,String startTime,String endTime) async {

    List<List<dynamic>> rows = [];

    List<dynamic> row = [];
    row.add("time");
    row.add("bearingAccuracy");
    row.add("speedAccuracy");
    row.add("verticalAccuracy");
    row.add("horizontalAccuracy");
    row.add("speed");
    row.add("bearing");
    row.add("altitude");
    row.add("longitude");
    row.add("latitude");

    rows.add(row);
    for (int i = 0; i < locationModelList.length; i++) {
      List<dynamic> row = [];
      row.add(locationModelList[i].time);
      row.add(locationModelList[i].bearingAccuracy);
      row.add(locationModelList[i].speedAccuracy);
      row.add(locationModelList[i].verticalAccuracy);
      row.add(locationModelList[i].horizontalAccuracy);
      row.add(locationModelList[i].speed);
      row.add(locationModelList[i].bearing);
      row.add(locationModelList[i].altitude);
      row.add(locationModelList[i].longitude);
      row.add(locationModelList[i].latitude);

      rows.add(row);
    }

    String csv = const ListToCsvConverter().convert(rows);
    await FileManager.writeIntoFolder("Location", csv,startTime,endTime);
  }
}