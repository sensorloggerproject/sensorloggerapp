import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';


customTextField({String? label,TextEditingController? controller,String? suffix}){
  return Padding(
    padding: const EdgeInsets.all(8.0),
    child: SizedBox(
      height: 40.h,
      width: 50.w,
      child: Row(
        children: [
          Expanded(
            child: TextField(
              keyboardType: TextInputType.number,
              controller: controller,
              decoration: new InputDecoration(
                  border: new OutlineInputBorder(
                      borderSide: new BorderSide(color: Colors.teal)
                  ),
                  labelText: label,
                  prefixIcon: const Icon(Icons.sensors, color: Colors.green,),
                  suffixStyle: const TextStyle(color: Colors.green)),
            ),
          ),
          SizedBox(width: 5.w,),
          Text("$suffix")
        ],
      ),
    ),
  );
}