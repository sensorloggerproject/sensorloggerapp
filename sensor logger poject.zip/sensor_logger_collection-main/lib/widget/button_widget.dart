import 'package:flutter/material.dart';

class AppButton extends StatelessWidget {
  const AppButton({
    Key? key,
    this.height,
    this.width,
    required this.color,
    required this.text,
    required this.onPressed,
    this.borderRadius,
  }) : super(key: key);
  final Color color;
  final String text;

  final VoidCallback onPressed;
  final double? height;
  final double? width;

  final double? borderRadius;

  @override
  Widget build(BuildContext context) {
    return MaterialButton(
      height: height,
      minWidth: width,
      color: color,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(borderRadius ?? 5),
      ),
      child: Text(
        text,
        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
      ),
      onPressed: onPressed,
    );
  }
}
