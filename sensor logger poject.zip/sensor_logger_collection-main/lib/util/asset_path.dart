class AssetsPath {
  static String accelerometer = 'assets/icons/accelerometer.png';
  static String audio = 'assets/icons/audio.png';
  static String barometer = 'assets/icons/barometer.png';
  static String bluetooth = 'assets/icons/bluetooth.png';
  static String gravity = 'assets/icons/gravity.png';
  static String gyroscope = 'assets/icons/gyroscope.png';
  static String process = 'assets/icons/process_icon.png';
  static String light = 'assets/icons/light.png';
  static String location = 'assets/icons/location.png';
  static String magnetometer = 'assets/icons/magnetometer.png';
  static String noise = 'assets/icons/noise.png';
}

final String soundTrack1 = "assets/audio/1.mpeg";
final String soundTrack2 = "assets/audio/2.mpeg";
final String soundTrack3 = "assets/audio/3.mpeg";
