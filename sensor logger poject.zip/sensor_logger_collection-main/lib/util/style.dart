import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:sensordatagetter/util/app_color.dart';

TextStyle inputTextStyle({double? size, Color? color}) {
  return TextStyle(color: color ?? Colors.white, fontSize: size ?? 24.sp, fontStyle: FontStyle.italic);
}

TextStyle headingStyle({double? size, Color? color}) {
  return TextStyle(
      color: color ?? Colors.black,
      fontSize: size ?? 16.sp,
      fontWeight: FontWeight.bold,
      fontStyle: FontStyle.italic);
}

TextStyle sensorTitle() {
  return TextStyle(
    color: Colors.black,
    fontWeight: FontWeight.bold,
    fontSize: 14.sp,
  );
}

TextStyle btnTextStyle({Color? color}) {
  return TextStyle(
    color: color ?? AppColors.bgColor,
    fontSize: 14.sp,
  );
}

//***********InputDecoration*********

InputDecoration kInputFieldDecoration = InputDecoration(
  filled: true,
  fillColor: Colors.white,
  border: OutlineInputBorder(
    borderSide: BorderSide(color: AppColors.deviationDialogColor),
    borderRadius: BorderRadius.all(Radius.circular(5.0)),
  ),
  enabledBorder: OutlineInputBorder(
    borderSide: BorderSide(color: AppColors.deviationDialogColor),
    borderRadius: BorderRadius.all(Radius.circular(5.0)),
  ),
  focusedBorder: OutlineInputBorder(
    borderSide: BorderSide(color: AppColors.deviationDialogColor),
    borderRadius: BorderRadius.all(Radius.circular(5.0)),
  ),
);
