import 'package:flutter/material.dart';

class AppColors {
  static Color bgColor = Color(0xffffffff);
  static Color btnColor = const Color(0xff36c688);
  static Color deviationDialogColor = const Color(0xff29323D);
  static Color appBarTextColor = const Color(0xff000000);
}
