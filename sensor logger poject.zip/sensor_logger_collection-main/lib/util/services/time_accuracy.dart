import 'package:ntp/ntp.dart';
import 'package:intl/intl.dart';
import 'package:sensordatagetter/util/alert.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:sprintf/sprintf.dart';

class TimeAccuracy {
  static int? milleseconds;
  static String? time;
  static Future<int> findDifference() async {
    try {
      DateTime startDate = new DateTime.now().toLocal();
      print("Start date is $startDate");
      int offset = await NTP.getNtpOffset(localTime: startDate);
      saveTimeDifference(offset);
      return offset;
    } catch (e) {
      MyAlert.showToast(e.toString());
      return 0;
    }
  }

  static String convertTime(int ts) {
    var dt = DateTime.fromMillisecondsSinceEpoch(ts, isUtc: false);
    var date = DateFormat('00:mm:ss:ms').format(dt);
    return date.toString();
  }

  static saveTimeDifference(int milliseconds) async {
    // Obtain shared preferences.
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('time', milliseconds);
  }

  static Future<int> getTimeDifference() async {
    // Obtain shared preferences.
    final prefs = await SharedPreferences.getInstance();
    int result = await prefs.getInt('time') ?? await findDifference();
    return result;
  }
}
