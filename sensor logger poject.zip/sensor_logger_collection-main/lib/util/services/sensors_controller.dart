import 'dart:async';
import 'dart:math';

import 'package:environment_sensors/environment_sensors.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_barometer_plugin/flutter_barometer.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:flutter_sensors/flutter_sensors.dart';
import 'package:flutter_sound/flutter_sound.dart';
import 'package:geolocator/geolocator.dart';
import 'package:intl/date_symbol_data_file.dart';

import 'package:light/light.dart';
// import 'package:location/location.dart';
import 'package:noise_meter/noise_meter.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:record/record.dart';
import 'package:record_mp3/record_mp3.dart';
import 'package:sensordatagetter/models/MagnetoModel.dart';
import 'package:sensordatagetter/models/acceleroModel.dart';
import 'package:sensordatagetter/models/baroModel.dart';
import 'package:sensordatagetter/models/bluetoothModel.dart';
import 'package:sensordatagetter/models/gyeroModel.dart';
import 'package:sensordatagetter/util/alert.dart';
import 'package:sensordatagetter/util/services/file_manager.dart';
import 'package:sensordatagetter/util/services/time_accuracy.dart';
// import 'package:sensors_plus/sensors_plus.dart';

import '../../models/gravityModel.dart';
import '../../models/lightModel.dart';
import '../../models/locationModel.dart';
import '../../models/noiseModel.dart';
import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart';
import 'package:assets_audio_player/assets_audio_player.dart';

import '../asset_path.dart';

class SensorsController {
  var acceleroStream, gyeroStream, magnetoStream;
  var gravityStream, noiseStream, lightStream;
  var locationStream, baroStream, bluetoothStream;

  Timer? noiseTimer, lightTimer, locationTimer, baroTimer, bluetoothTimer, audioTimer;

  List<AcceleroModel> acceleroModelList = [];
  List<GyeroModel> gyeroModelList = [];
  List<MagnetoModel> magnetoModelList = [];

  List<GravityModel> gravityModelList = [];
  List<NoiseModel> noiseModelList = [];
  List<LightModel> lightModelList = [];

  List<BaroModel> baroModelList = [];
  List<BluetoothModel> bluetoothModelList = [];
  List<LocationModel> locationModelList = [];

  String? startTime, endTime;
  startTimer() {
    startTime = DateTime.now().millisecondsSinceEpoch.toString();
  }

  // get AcceleroMeter Stream
  getAccelerometerStream(int interval) async {
    final stream = await SensorManager()
        .sensorUpdates(sensorId: Sensors.LINEAR_ACCELERATION, interval: Duration(milliseconds: interval));
    acceleroModelList.clear();
    acceleroStream = stream.listen((event) {
      int updatedTime = DateTime.now().millisecondsSinceEpoch + TimeAccuracy.milleseconds!;
      acceleroModelList.add(AcceleroModel(
          time: updatedTime.toString(), zAxis: event.data[2], yAxis: event.data[1], xAxis: event.data[0]));
    });
    // acceleroModelList.clear();
    // acceleroStream=userAccelerometerEvents.listen((UserAccelerometerEvent event) {
    //   print(event);
    //   acceleroModelList.add(AcceleroModel(time:DateTime.now().millisecondsSinceEpoch.toString(),zAxis: event.z,yAxis: event.y,xAxis: event.x));
    // });
  }

  getGyroscopeStream(int interval) async {
    gyeroModelList.clear();
    final stream = await SensorManager()
        .sensorUpdates(sensorId: Sensors.GYROSCOPE, interval: Duration(milliseconds: interval));
    gyeroStream = stream.listen((event) {
      int updatedTime = DateTime.now().millisecondsSinceEpoch + TimeAccuracy.milleseconds!;
      gyeroModelList.add(GyeroModel(
          time: updatedTime.toString(), zAxis: event.data[2], yAxis: event.data[1], xAxis: event.data[0]));
    });
  }

  getGravityStream(int interval) async {
    gravityModelList.clear();
    final stream = await SensorManager()
        .sensorUpdates(sensorId: Sensors.ACCELEROMETER, interval: Duration(milliseconds: interval));
    gravityStream = stream.listen((event) {
      int updatedTime = DateTime.now().millisecondsSinceEpoch + TimeAccuracy.milleseconds!;
      gravityModelList.add(GravityModel(
          time: updatedTime.toString(), zAxis: event.data[2], yAxis: event.data[1], xAxis: event.data[0]));
    });
  }

  getMagnetometerStream(int interval) async {
    magnetoModelList.clear();
    final stream = await SensorManager()
        .sensorUpdates(sensorId: Sensors.MAGNETIC_FIELD, interval: Duration(milliseconds: interval));
    magnetoStream = stream.listen((event) {
      int updatedTime = DateTime.now().millisecondsSinceEpoch + TimeAccuracy.milleseconds!;
      magnetoModelList.add(MagnetoModel(
          time: updatedTime.toString(), zAxis: event.data[2], yAxis: event.data[1], xAxis: event.data[0]));
    });
  }

  getNoiseStream(int interval) {
    NoiseMeter _noiseMeter = NoiseMeter();
    noiseModelList.clear();
    noiseTimer = Timer.periodic(Duration(milliseconds: interval), (timer) {
      bool getValue = true;
      noiseStream = _noiseMeter.noiseStream.listen((NoiseReading noiseReading) {
        if (getValue) {
          print("Noise reading is : $noiseReading");
          int updatedTime = DateTime.now().millisecondsSinceEpoch + TimeAccuracy.milleseconds!;
          noiseModelList.add(NoiseModel(time: updatedTime.toString(), dBFS: noiseReading.maxDecibel));
          getValue = false;
        }
      });
    });
  }

  getAndSaveMicroPhoneRecording(double sampleRate) async {
    print("sample rate is $sampleRate");
    await Permission.microphone.request();
    int updatedTime = DateTime.now().millisecondsSinceEpoch + TimeAccuracy.milleseconds!;
    String filePath =
        await FileManager.getRecodingPath(DateTime.fromMillisecondsSinceEpoch(updatedTime).toString());
    startRecord(filePath);
  }

  Light _light = Light();
  getLightStream(int interval) {
    lightModelList.clear();
    lightTimer = Timer.periodic(Duration(milliseconds: interval), (timer) {
      bool getValue = true;
      lightStream = _light.lightSensorStream.listen((luxValue) {
        if (getValue) {
          print("Light lux value $luxValue");
          int updatedTime = DateTime.now().millisecondsSinceEpoch + TimeAccuracy.milleseconds!;
          lightModelList.add(LightModel(time: updatedTime.toString(), lux: luxValue));
          getValue = false;
        }
      });
    });
  }

  getBarometerStream(int interval) {
    baroModelList.clear();
    try {
      print("getting barometer");
      baroTimer = Timer.periodic(Duration(milliseconds: interval), (timer) {
        bool getValue = true;
        baroStream = FlutterBarometer.currentPressureEvent.listen((event) {
          if (getValue) {
            print("Barometer Data $event");
            int updatedTime = DateTime.now().millisecondsSinceEpoch + TimeAccuracy.milleseconds!;
            baroModelList.add(BaroModel(time: updatedTime.toString(), pressure: event.hectpascal));
            getValue = false;
          }
        });
      });
    } catch (e) {
      print("Error is ${e.toString()}");
    }
  }

  FlutterBluePlus flutterBlue = FlutterBluePlus.instance;
  final assetsAudioPlayer = AssetsAudioPlayer();
  destroyAudio() {
    audioTimer?.cancel();
    assetsAudioPlayer.stop();
  }

  getBluetoothStream(int interval) async {
    if (FlutterBluePlus.instance.isScanning == false) {
      await flutterBlue.startScan(timeout: Duration(seconds: 2));
      print("Scanning completed");
    } else {
      print("Scanning stated again");
      flutterBlue.stopScan();
      await flutterBlue.startScan(timeout: Duration(seconds: 2));
      print("Scanning completed again");
    }

    bluetoothModelList.clear();
    Random random = new Random();
    int randomNumber1 = random.nextInt(3) + 1;
    int randomNumber2 = random.nextInt(3) + 1;
    int randomNumber3 = random.nextInt(3) + 1;
    try {
      if (assetsAudioPlayer.isPlaying.value) {
        assetsAudioPlayer.stop();
      }
      assetsAudioPlayer.open(
        Playlist(audios: [
          Audio("assets/audio/$randomNumber1.mpeg"),
          Audio("assets/audio/$randomNumber2.mpeg"),
          Audio("assets/audio/$randomNumber3.mpeg")
        ]),
        //loop the full playlist
      );
      assetsAudioPlayer.play();
      audioTimer = Timer.periodic(Duration(seconds: 60), (timer) {
        Random random = new Random();
        randomNumber1 = random.nextInt(3) + 1;
        randomNumber2 = random.nextInt(3) + 1;
        randomNumber3 = random.nextInt(3) + 1;

        if (assetsAudioPlayer.isPlaying.value) {
          assetsAudioPlayer.stop();
        }

        assetsAudioPlayer.open(
          Playlist(audios: [
            Audio("assets/audio/$randomNumber1.mpeg"),
            Audio("assets/audio/$randomNumber2.mpeg"),
            Audio("assets/audio/$randomNumber3.mpeg")
          ]),
        );

        assetsAudioPlayer.play();
      });
      print("getting blueetooth");

      bluetoothTimer = Timer.periodic(Duration(seconds: interval), (timer) {
        bool getValue = true;
        bluetoothStream = flutterBlue.scanResults.listen((results) {
          if (getValue) {
            print("result is $results");
            for (ScanResult r in results) {
              print('Name : ${deviceName(r)} rssi: ${deviceSignal(r)} MAc Address ${deviceMacAddress(r)}');
              int updatedTime = DateTime.now().millisecondsSinceEpoch + TimeAccuracy.milleseconds!;
              bluetoothModelList.add(BluetoothModel(
                  time: updatedTime.toString(),
                  rssi: r.rssi,
                  bleMacAddress: r.device.id.id,
                  chirp: getFrequencyNumber(randomNumber1) +
                      getFrequencyNumber(randomNumber2) +
                      getFrequencyNumber(randomNumber3)));
            }
            getValue = false;
          }
        });
      });
    } catch (e) {
      print("Error is ${e.toString()}");
    }
  }

  String getFrequencyNumber(int number) {
    if (number == 1) {
      return "10";
    }
    if (number == 2) {
      return "15";
    }

    return "20";
  }

  String deviceName(ScanResult r) {
    String name = '';

    if (r.device.name.isNotEmpty) {
      // device.name
      name = r.device.name;
    } else if (r.advertisementData.localName.isNotEmpty) {
      // advertisementData.localName
      name = r.advertisementData.localName;
    } else {
      name = 'N/A';
    }
    return name;
  }

  int deviceSignal(ScanResult r) {
    return r.rssi;
  }

  String deviceMacAddress(ScanResult r) {
    return r.device.id.id;
  }

  LocationSettings locationSettings = LocationSettings(
    accuracy: LocationAccuracy.high,
    distanceFilter: 0,
  );

  getLocationStream(int interval) async {
    locationModelList.clear();
    print("started getting location.......");
    locationTimer = Timer.periodic(Duration(seconds: interval), (timer) {
      bool getValue = true;
      locationStream = Geolocator.getPositionStream().listen((Position? currentLocation) {
        if (getValue) {
          print(" location: ${currentLocation}");
          int updatedTime = DateTime.now().millisecondsSinceEpoch + TimeAccuracy.milleseconds!;
          locationModelList.add(LocationModel(
              time: updatedTime.toString(),
              bearingAccuracy: currentLocation!.accuracy,
              speedAccuracy: currentLocation.speedAccuracy,
              verticalAccuracy: currentLocation.accuracy,
              horizontalAccuracy: currentLocation.accuracy,
              speed: currentLocation.speed,
              bearing: currentLocation.heading,
              altitude: currentLocation.altitude,
              latitude: currentLocation.latitude,
              longitude: currentLocation.longitude));
          getValue = false;
        }
      });
    });
  }

  cancel(List<bool> currentSensors) async {
    closeAllStream(currentSensors);
    endTime = DateTime.now().millisecondsSinceEpoch.toString();

    // accelero
    if (currentSensors[0]) {
      AcceleroModel().saveAcceleroValues(acceleroModelList, startTime!, endTime!);
    }
    //gyero
    if (currentSensors[1]) {
      GyeroModel().saveGyeroValues(gyeroModelList, startTime!, endTime!);
    }
    // magneto
    if (currentSensors[2]) {
      MagnetoModel().saveMagnetoValues(magnetoModelList, startTime!, endTime!);
    }
    // gravity
    if (currentSensors[3]) {
      GravityModel().saveGravityValues(gravityModelList, startTime!, endTime!);
    }
    // noise
    if (currentSensors[4]) {
      NoiseModel().saveNoiseValues(noiseModelList, startTime!, endTime!);
    }
    // light
    if (currentSensors[6]) {
      LightModel().saveLightValues(lightModelList, startTime!, endTime!);
    }
    // barometer
    if (currentSensors[7]) {
      BaroModel().saveBaroValues(baroModelList, startTime!, endTime!);
    }
    // location
    if (currentSensors[8]) {
      LocationModel().saveLocationValues(locationModelList, startTime!, endTime!);
    }
    // bluetooth
    if (currentSensors[9]) {
      BluetoothModel().saveBluetoothValues(bluetoothModelList, startTime!, endTime!);
    }
  }

  closeAllStream(List<bool> currentSensors) async {
    if (currentSensors[0]) {
      acceleroStream.cancel();
    }
    if (currentSensors[1]) {
      gyeroStream.cancel();
    }
    if (currentSensors[2]) {
      magnetoStream.cancel();
    }
    if (currentSensors[3]) {
      gravityStream.cancel();
    }
    if (currentSensors[4]) {
      noiseStream.cancel();
      noiseTimer!.cancel();
    }
    // micro phone
    if (currentSensors[5]) {
      stopRecord();
    }
    // light
    if (currentSensors[6]) {
      lightStream.cancel();
      lightTimer!.cancel();
    }
    // barometer
    if (currentSensors[7]) {
      baroStream.cancel();
      baroTimer!.cancel();
    }
    // location
    if (currentSensors[8]) {
      if (locationStream != null) {
        locationStream.cancel();
      }
      locationTimer!.cancel();
    }
    // bluetooth
    if (currentSensors[9]) {
      if (bluetoothStream != null) {
        bluetoothStream.cancel();
      }
      bluetoothTimer!.cancel();
    }
  }

  Future<bool> isBaroAvailable() async {
    final environmentSensors = EnvironmentSensors();
    bool pressureAvailable = await environmentSensors.getSensorAvailable(SensorType.Pressure);
    return pressureAvailable;
  }

  FlutterSoundRecorder soundRecorder = FlutterSoundRecorder();
  Record recorder = Record();

  void startRecord(String path) async {
    await soundRecorder.startRecorder(toFile: path, codec: Codec.pcm16WAV);
  }

  void stopRecord() {
    // recorder.stop();
    soundRecorder.stopRecorder();
  }

  Future<void> openTheRecorder() async {
    await soundRecorder.openRecorder();
    bool result = await soundRecorder.isEncoderSupported(Codec.aacMP4);
    print("Codec supported $result");
  }

  SensorsController() {
    openTheRecorder();
  }
}
