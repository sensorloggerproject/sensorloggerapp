import 'dart:core';
import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

class FileManager {
  static Future<String> createFolderInAppDocDir(String folderName) async {
    //Get this App Document Directory

    final Directory _appDocDir = await getApplicationDocumentsDirectory();
    //App Document Directory + folder name
    final Directory _appDocDirFolder = Directory('${_appDocDir.path}/$folderName/');

    if (await _appDocDirFolder.exists()) {
      //if folder already exists return path
      return _appDocDirFolder.path;
    } else {
      //if folder not exists create folder and then return its path
      final Directory _appDocDirNewFolder = await _appDocDirFolder.create(recursive: true);
      return _appDocDirNewFolder.path;
    }
  }

  static writeIntoFolder(String folder, String csv, String startTime, String endTime,
      {String? timeWindowValue, String? oldName, bool audioIsProcessed = false}) async {
    // final PermissionHandler _permissionHandler = PermissionHandler();
    // var result = await _permissionHandler.requestPermissions([PermissionGroup.storage]);
    // if (result[PermissionGroup.storage] == PermissionStatus.granted) {

    final Directory _appDocDir = await getApplicationDocumentsDirectory();
    //App Document Directory + folder name
    final Directory dir = Directory('${_appDocDir.path}/$folder');
    if (!await dir.exists()) {
      await createFolderInAppDocDir(folder);
    }
    print("dir $dir");
    String file = dir.path;

    String filePath = "${file}/<${startTime}><${endTime}><${folder}>.csv";
    if (timeWindowValue != null) {
      filePath = "${file}/<Processed>${oldName}<${startTime}><${endTime}><${timeWindowValue}>.csv";
    }
    if (audioIsProcessed) {
      filePath = "${file}/<Processed>${oldName}.csv";
    }
    File f = File(filePath);

    f.writeAsString(csv);
  }

  static Future<String> getRecodingPath(String startTime) async {
    final Directory _appDocDir = await getApplicationDocumentsDirectory();
    final Directory dir = Directory('${_appDocDir.path}/Microphone audio');
    if (!await dir.exists()) {
      await createFolderInAppDocDir("Microphone audio");
    }
    String file = dir.path;
    String filePath = "${file}/<${startTime}><Microphone audio>.wav";

    return filePath;
  }
}
